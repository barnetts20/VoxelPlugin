Ocean harnesses (stages O1-O4, O6a). Plain C++20; no engine. Each file's head comment says what it checks.

  ocean_tiles_harness.cpp   the selection and tile geometry of VoxelOceanTiles.h, compiled unchanged:
                            balance, morph chains, seams and cracks under test waves, rays.
      g++ -O2 -std=c++20 -DVOT_HEADER='"<plugin>/Source/VoxelPlugin/Public/VoxelOceanTiles.h"' -I. ocean_tiles_harness.cpp -o ocean_tiles_harness
      (several minutes; expected_tiles_o4.txt is the O4 run's output)
  ocean_pages_stats.cpp     pages, slots and triangles per frame (same -DVOT_HEADER and -I.)
  waves_check.cpp           O4: the wave hook's maths (normal, Jacobian, velocity), the CPU query's
                            convergence, the shader's float height against the query, the underwater exit
  underwater_check.cpp      O3b: VoxelUnderwater.ush's float maths against double references
  ray_check.cpp             O3b: the underwater pass's ray from the depth buffer
  normal_check.cpp          O2b: VoxelOceanPixel's normal against finite differences
      g++ -O2 -std=c++20 <file>.cpp -o <name>

  spectrum_check.cpp        O6a: the FFT cascades' shared code (VoxelOceanSpectrum.ush) and CPU side
                            (VoxelOceanSpectrum.h): spreading, Hs per wind, band split, exact dispersion,
                            the GPU passes emulated in float against a direct DFT, variance, time loop,
                            the 128^2 query cascades, fp16, folding, detiling, determinism, CPU cost
  spectrum_view.cpp         O6a: pictures of the sea from the emulated cascades (perspective from an
                            altitude, top-down relief), with or without detiling
  ocean_fft_emulation.h     VoxelOceanFFT.usf's passes in float, shared by the two above
      g++ -O2 -std=c++20 -ffp-contract=off -I<plugin>/Source/VoxelPlugin/Public -I<plugin>/Source/VoxelPlugin/Private
          -I<plugin>/Shaders/Private -I. spectrum_check.cpp -o spectrum_check     (same for spectrum_view)
      ./spectrum_view <wind> persp|top <altitude or extent m> <detile cell m, 0 off> <detiled bands> out.ppm

CoreMinimal.h is a stand-in for the UE types VoxelOceanTiles.h uses. waves_check, underwater_check,
ray_check and normal_check reimplement the test model and the shader maths in double/float; the
FFT model (O6) should replace them with checks built on its shared HLSL/C++ code.
